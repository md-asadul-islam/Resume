// icon-page.js
document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById("iconSearch");
  const icons = document.querySelectorAll(".icon-card");
  const filterBtns = document.querySelectorAll(".filter-btn");

  // Search filter
  searchInput.addEventListener("input", () => {
    const value = searchInput.value.toLowerCase();
    icons.forEach(icon => {
      const name = icon.dataset.name;
      icon.style.display = name.includes(value) ? "block" : "none";
    });
  });

  // Category filter
  filterBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      filterBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const category = btn.dataset.category;
      icons.forEach(icon => {
        if (category === "all" || icon.dataset.category === category) {
          icon.style.display = "block";
        } else {
          icon.style.display = "none";
        }
      });
    });
  });

  // Copy code functionality
  document.querySelectorAll(".copy-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const code = btn.dataset.code;
      navigator.clipboard.writeText(code);
      btn.innerText = "Copied!";
      setTimeout(() => {
        btn.innerText = "Copy";
      }, 1000);
    });
  });
});
